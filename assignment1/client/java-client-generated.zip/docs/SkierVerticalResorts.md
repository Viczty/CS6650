# SkierVerticalResorts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**seasonID** | **String** |  |  [optional]
**totalVert** | **Integer** |  |  [optional]
