# LiftRide

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**time** | **Integer** |  |  [optional]
**liftID** | **Integer** |  |  [optional]
